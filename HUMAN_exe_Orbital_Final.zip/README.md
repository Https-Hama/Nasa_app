# HUMAN.exe — Orbital

A complete local browser space game built from the supplied HUMAN.exe proposal, with custom AI-generated mission artwork, React Bits animation, a procedural Three.js world, and OpenCV plus MediaPipe full-body controls.

## Play

Double-click **START_HUMAN_EXE.cmd**. The included production build opens in your browser. Node.js 22 or newer is required. Keep the launcher window open while playing; Ctrl+C stops the local server. The production game works without an internet connection.

Choose one of four missions: **Orbital Run**, **Reactor Recall**, **Perfect Approach**, or **Zero-G Training**. Use the keyboard immediately or enable body tracking and allow the browser's camera prompt. The full control guide is available inside the game and in [PLAY_GUIDE.md](PLAY_GUIDE.md).

The exercise circuit counts four squat-and-rise cycles, four alternating knee-lift cycles and four overhead reach-and-lower cycles. Keyboard E generates explicitly labeled practice reps. The camera recognizes movement; the game does not supply resistance, diagnose a condition, measure bone or muscle health, or replace an astronaut's prescribed exercise equipment.

## Development

```powershell
npm install
npm run assets
npm run dev
```

```powershell
npm test
npm run build
```

Node 22.12+ is recommended for development. Runtime dependencies are locked in `package-lock.json`. `npm run assets` installs the OpenCV JavaScript runtime, MediaPipe WASM and lite pose model into `public`. Camera frames pass through actual OpenCV preprocessing before local pose inference. Models and artwork are included in the production build.

## Layout

- `src/game.js`, `src/simulation.js` — 3D scenes and mission rules.
- `src/body-controller.js`, `src/pose.js` — camera lifecycle, OpenCV preprocessing, pose calibration and movement recognition.
- `src/main.js`, `src/style.css` — game interface, controls, privacy choices and results.
- `src/react-bits.jsx` — source-adapted React Bits StarBorder and ShinyText.
- `public/art` — four custom generated artworks with exact prompts and provenance.
- `public/data/nasa-reference.json` — source-linked NASA educational context loaded at runtime.
- `dist` — ready-to-play production build.
- `tests` — meaningful recognition, mission simulation and session-data tests.

## Privacy

Camera access is opt-in. Video frames are processed locally and never saved or uploaded. Optional local history stores at most 30 derived session summaries. Flight log export and deletion are available inside the game. No account or backend is required.

## Verification

See [VERIFICATION.md](VERIFICATION.md) for completed checks and hardware limitations. Actual person-specific recognition accuracy and webcam performance still need a real-person playtest on the intended computer.

Third-party licensing and attribution are documented in [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md). NASA references supply educational context and do not imply endorsement.
