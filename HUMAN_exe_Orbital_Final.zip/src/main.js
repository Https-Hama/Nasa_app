import './style.css';
import { OrbitGame } from './game.js';
import { BodyController } from './body-controller.js';
import { icon } from './icons.js';
import { summarizeResult, safeHistory, addSession } from './session.js';
import { mountReactBits } from './react-bits.jsx';

const missions = [
  {id:'asteroids',name:'Orbital run',tag:'FLIGHT / REACTION',icon:'asteroid',time:'60 SEC',desc:'Thread the asteroid belt. Protect your ship. Find your flow.',objective:'Dodge debris and collect energy cores.',control:'Lean to steer · raise arms to shield'},
  {id:'memory',name:'Reactor recall',tag:'COGNITION / MEMORY',icon:'memory',time:'90 SEC',desc:'Restore the reactor by repeating its directional signal.',objective:'Watch the signal. Repeat the sequence.',control:'Lean in a direction · raise arms to confirm'},
  {id:'docking',name:'Perfect approach',tag:'PRECISION / CONTROL',icon:'target',time:'60 SEC',desc:'A steady body. A steady ship. Bring it home.',objective:'Align with the moving beacon and hold steady.',control:'Lean left, right, forward and back to align'},
  {id:'exercise',name:'Zero-G training',tag:'MOVEMENT / EXERCISE',icon:'body',time:'12 REPS',desc:'Power life support with a full-body movement circuit.',objective:'4 squats → 4 alternating knee lifts → 4 reaches.',control:'Stand in full view · move at your own pace'},
];
const $ = id => document.getElementById(id);
const escape = value => String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const storage = {get(key){try{return localStorage.getItem(key);}catch{return null;}},set(key,value){try{localStorage.setItem(key,value);}catch{toast('Local storage is unavailable. This session remains in memory.');}},remove(key){try{localStorage.removeItem(key);}catch{}}};
let history = safeHistory(storage.get('human-exe-history'));
let settings;
try{ settings=JSON.parse(storage.get('human-exe-settings')||'{}'); }catch{settings={};}
if(!settings||typeof settings!=='object')settings={};
settings={sound:false,history:false,sensitivity:1,...settings};
let selected='asteroids', inputMode='keyboard', cameraActive=false, calibrated=false, fullBody=false, currentView='missions', snapshot=null, cameraState='off', nasa=null, lastShield=false, exerciseType='squat', heldDirection='left', savingResult=false;
const keys = new Set();
let audio;

const skeleton = `<svg class="body-skeleton" viewBox="0 0 200 240" fill="none" aria-hidden="true"><g stroke="currentColor" stroke-width="1.6"><circle cx="100" cy="40" r="14"/><path d="m79 69 21-6 21 6m-42 0-20 32-14 27m76-59 20 32 14 27M79 69l5 62h32l5-62M84 131l-7 44-5 44m44-88 7 44 5 44M84 94h32"/></g><g fill="currentColor">${[[79,69],[121,69],[59,101],[141,101],[45,128],[155,128],[84,131],[116,131],[77,175],[123,175],[72,219],[128,219],[100,63]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3.2"/>`).join('')}</g><g stroke="currentColor" opacity=".18"><path d="M15 18h20M15 18v20m170-20h-20m20 0v20M15 227h20m-20 0v-20m170 20h-20m20 0v-20"/></g></svg>`;

$('app').innerHTML = `
<aside class="sidebar">
 <a class="brand" href="#" aria-label="HUMAN.exe home"><span class="brand-mark">H<span>·</span></span><span>HUMAN<span class="exe">.exe</span><small>ORBITAL PROGRAM</small></span></a>
 <div class="workspace-label"><i class="dot orange"></i> ODYSSEY / CREW 01</div>
 <nav aria-label="Main navigation">${[['missions','grid','Mission control'],['history','log','Flight log'],['guide','book','Field guide'],['settings','settings','Settings']].map(([id,i,text])=>`<button class="nav-item ${id==='missions'?'active':''}" data-view="${id}">${icon(i)}<span>${text}</span>${id==='missions'?'<span class="nav-indicator"></span>':''}</button>`).join('')}</nav>
 <div class="sidebar-bottom"><div class="orbit-symbol">${icon('orbit',50)}</div><p>Made to move.<br><strong>Built for the beyond.</strong></p><div class="sidebar-divider"></div><span class="version"><i class="dot cyan"></i> LOCAL SYSTEM <b>V 1.0</b></span><small class="privacy-note">Your camera. Your space.<br>Video stays on this device.</small></div>
</aside>
<div class="shell">
 <header class="topbar"><div class="breadcrumb">ODYSSEY <span>/</span> <strong id="breadcrumb">MISSION CONTROL</strong></div><div class="topbar-right"><span class="system"><i class="dot cyan"></i> SYSTEM ONLINE</span><button class="icon-button" id="sound-toggle" aria-label="Enable sound" title="Toggle sound">${icon('sound',18)}</button><button class="crew" id="crew-guide" aria-label="Open field guide"><span>01</span><div>EXPLORER<small>EARTH CREW</small></div></button></div></header>
 <main>
 <section id="missions-view">
  <div class="page-heading"><div><div class="eyebrow" id="react-tagline">THE HUMAN SIDE OF SPACE</div><h1>Your next giant leap<span>.</span></h1><p>A space adventure powered by you. Move. Explore. Stay human.</p></div><div class="orbit-stamp">${icon('orbit',28)}<div>LOW EARTH ORBIT<small>408 KM ABOVE THE ORDINARY</small></div></div></div>
  <div class="dashboard">
   <div class="main-column">
    <div class="section-heading"><h2>Choose your mission</h2><span>04 MISSIONS AVAILABLE</span></div>
    <div class="mission-list">${missions.map((m,i)=>`<button class="mission-card ${i===0?'selected':''}" data-mission="${m.id}" aria-pressed="${i===0}"><div class="mission-card-top"><span class="mission-icon">${icon(m.icon,22)}</span><span class="mission-number">0${i+1}</span></div><strong>${m.name}</strong><span class="mission-card-meta">${m.tag.split(' / ')[0]} <i>·</i> ${m.time}</span><span class="card-line"></span></button>`).join('')}</div>
    <section class="flight-stage" id="flight-stage" aria-label="3D game viewport">
     <canvas id="game-canvas" tabindex="0" aria-label="Space game. Use arrow keys or WASD to steer, Space to shield, P to pause."></canvas>
     <div class="stage-vignette"></div><div class="stage-grid"></div>
     <div class="stage-top"><span class="stage-label"><i class="dot orange"></i> LIVE SIMULATION <b id="stage-mission-number">/ 01</b></span><button id="fullscreen" class="stage-icon" aria-label="Toggle full screen">${icon('expand',17)}</button></div>
     <div class="stage-title" id="stage-title"><span id="stage-tag">FLIGHT / REACTION</span><h2 id="stage-name">ORBITAL<br>RUN</h2><p id="stage-description">Navigate the unknown.<br>Let your instincts take flight.</p></div>
     <div class="live-hud" id="live-hud" hidden><div><span>MISSION TIME</span><b id="hud-time">01:00</b></div><div><span>ENERGY SCORE</span><b id="hud-score">0000</b></div><div><span>SHIP INTEGRITY</span><b id="hud-hull">100%</b></div></div>
     <div id="memory-pads" class="memory-pads" hidden>${['left','up','down','right'].map((d,i)=>`<div data-pad="${i}"><span>${['←','↑','↓','→'][i]}</span><small>${d.toUpperCase()}</small></div>`).join('')}</div>
     <div class="crosshair" id="crosshair"><span></span><i></i></div>
     <div class="stage-coordinate">ODYSSEY–01 <span>28.5° N / 80.6° W</span></div>
     <div class="stage-bottom" id="idle-stage-bottom"><span>SECTOR 07 <i></i> EARTH APPROACH</span><div class="stage-signal"><i></i><i></i><i></i><i></i><i></i></div></div>
     <div class="game-objective" id="game-objective" hidden><span id="objective-label">MISSION OBJECTIVE</span><strong id="objective-text"></strong><div class="mission-progress"><i id="mission-progress-fill"></i></div><small id="objective-detail"></small></div>
     <div id="pause-overlay" class="pause-overlay" hidden><span class="eyebrow">TAKE YOUR TIME</span><h2>Mission paused.</h2><p id="pause-reason">Your ship is holding position.</p><button class="primary-button" id="resume">Resume mission ${icon('play',17)}</button><button class="text-button" id="end-mission">Finish this session</button></div>
     <div class="exercise-badge" id="exercise-badge" hidden><span id="exercise-name">SQUAT & RISE</span><b id="exercise-count">0 <small>/ 4</small></b><span id="exercise-note">Stand tall to begin</span></div>
    </section>
    <div class="launch-strip"><div><span class="eyebrow" id="launch-label">MISSION 01 / READY FOR LAUNCH</span><h3 id="launch-title">Your body is the controller.</h3><p id="launch-description">Lean to steer. Raise your arms to shield. Space is yours.</p></div><div class="launch-actions"><span class="input-badge" id="input-badge">${icon('grid',13)} KEYBOARD MODE</span><div class="launch-wrapper"><button class="primary-button" id="launch"><span id="launch-react" aria-hidden="true"></span><span>Launch mission</span> ${icon('arrow',18)}</button></div><button id="pause-button" class="primary-button" hidden>Pause mission ${icon('pause',18)}</button></div></div>
    <div class="controls-strip"><span>${icon('body',18)} <b id="control-title">Move naturally. Play differently.</b></span><div id="control-hints"><kbd>W A S D</kbd><span>steer</span><kbd>SPACE</kbd><span>shield</span><kbd>P</kbd><span>pause</span></div><button class="text-button" id="controls-help">All controls ${icon('arrow',13)}</button></div>
    <div class="science-strip"><span class="science-icon">${icon('orbit',25)}</span><div><span class="eyebrow">A MISSION WITH MEANING</span><p id="science-summary">In space, movement matters. Discover the science behind every mission.</p></div><button class="text-button" id="science-more">Explore the science ${icon('arrow',15)}</button></div>
   </div>
   <aside class="right-rail">
    <section class="panel tracking-panel"><div class="panel-heading"><h2>Body link</h2><span id="camera-status-pill" class="mini-pill">OFFLINE</span></div><div class="tracking-preview"><div class="tracking-grid"></div><video id="camera-video" playsinline muted hidden></video><canvas id="pose-overlay" hidden></canvas><div id="camera-placeholder">${skeleton}<span>YOUR BODY. YOUR CONTROLLER.</span></div><div class="tracking-corner tl"></div><div class="tracking-corner tr"></div><div class="tracking-corner bl"></div><div class="tracking-corner br"></div><div class="camera-preview-status"><i class="dot"></i><span id="preview-status">AWAITING CONNECTION</span></div></div><div class="tracking-copy"><h3 id="tracking-title">Make the connection.</h3><p id="tracking-message">Enable your camera to turn movement into flight. Processed on your device.</p></div><button class="outline-button" id="enable-camera">${icon('camera',17)} Enable body tracking <span>↗</span></button><div class="camera-actions" id="camera-actions" hidden><button class="text-button" id="recalibrate">Recalibrate</button><button class="text-button" id="keyboard-mode">Use keyboard</button><button class="text-button" id="camera-off">Disconnect</button></div><div class="tracking-metrics"><div><span>POSE POINTS</span><b id="pose-points">— <small>/ 33</small></b></div><div><span>TRACKING</span><b id="tracking-fps">— <small>FPS</small></b></div><div><span>BODY VIEW</span><b id="body-view">—</b></div></div></section>
    <section class="panel training-panel"><div class="panel-heading"><h2>Train beyond gravity</h2><span class="orange-icon">${icon('spark',18)}</span></div><p>Small movements.<br><strong>A stronger mission.</strong></p><div class="training-steps"><span><b>01</b> Squat & rise <i>×4</i></span><span><b>02</b> Alternating knees <i>×4</i></span><span><b>03</b> Overhead reach <i>×4</i></span></div><button class="text-button orange-text" id="choose-exercise">Enter Zero-G training ${icon('arrow',15)}</button><small>Inspired by astronaut exercise. A movement game, not a substitute for resistance training.</small></section>
    <div class="session-counter"><span class="counter-orbit">${icon('orbit',32)}</span><div><strong id="session-total">${history.length.toString().padStart(2,'0')}</strong><span>MISSIONS LOGGED</span></div><button id="open-history" aria-label="Open flight log">${icon('arrow',17)}</button></div>
   </aside>
  </div>
 </section>
 <section id="history-view" class="secondary-view" hidden></section>
 <section id="guide-view" class="secondary-view" hidden></section>
 <section id="settings-view" class="secondary-view" hidden></section>
 <footer><span>HUMAN.exe <i>©</i> 2026</span><span>STAY CURIOUS. KEEP MOVING.</span><span><i class="dot cyan"></i> LOCAL-FIRST EXPLORATION</span></footer>
 </main>
</div>
<dialog id="result-dialog" class="result-dialog"></dialog><dialog id="help-dialog" class="help-dialog"></dialog><div id="toast" role="status" aria-live="polite"></div>`;

const game = new OrbitGame({canvas:$('game-canvas'),onState:renderState,onEvent:handleGameEvent});
const body = new BodyController({video:$('camera-video'),overlay:$('pose-overlay'),onInput:handleBodyInput,onStatus:handleBodyStatus,onMetrics:renderBodyMetrics});
mountReactBits();

function toast(message){$('toast').textContent=message;$('toast').classList.add('visible');clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('toast').classList.remove('visible'),4200);}
function beep(type='click'){
 if(!settings.sound)return;
 try{audio ||= new (window.AudioContext||window.webkitAudioContext)();audio.resume();const o=audio.createOscillator(),g=audio.createGain();o.type='sine';o.frequency.setValueAtTime(type==='rep'?660:type==='complete'?880:300,audio.currentTime);o.frequency.exponentialRampToValueAtTime(type==='rep'?990:480,audio.currentTime+.12);g.gain.setValueAtTime(.045,audio.currentTime);g.gain.exponentialRampToValueAtTime(.001,audio.currentTime+.22);o.connect(g);g.connect(audio.destination);o.start();o.stop(audio.currentTime+.23);}catch{}
}
function mission(){return missions.find(m=>m.id===selected);}
function active(){return snapshot&&['running','paused'].includes(snapshot.status);}
function selectMission(id){
 if(active()){toast('Finish the current session before changing missions.');return;}
 clearTimeout(toast.timer);$('toast').classList.remove('visible');
 selected=id;game.preview?.(id);
 document.querySelectorAll('[data-mission]').forEach(el=>{el.classList.toggle('selected',el.dataset.mission===id);el.setAttribute('aria-pressed',el.dataset.mission===id);});
 const m=mission(),index=missions.indexOf(m)+1;
 $('stage-tag').textContent=m.tag;$('stage-name').innerHTML=escape(m.name).toUpperCase().split(' ').join('<br>');$('stage-description').textContent=m.desc;$('stage-mission-number').textContent=`/ 0${index}`;
 $('launch-label').textContent=`MISSION 0${index} / READY FOR LAUNCH`;$('launch-title').textContent=id==='exercise'?'Movement is your mission.':'Your body is the controller.';$('launch-description').textContent=m.control;
 $('control-hints').innerHTML=id==='exercise'?'<kbd>E</kbd><span>practice rep</span><kbd>P</kbd><span>pause</span>':id==='memory'?'<kbd>↑ ← ↓ →</kbd><span>repeat the signal</span><kbd>P</kbd><span>pause</span>':'<kbd>W A S D</kbd><span>steer</span><kbd>SPACE</kbd><span>shield</span><kbd>P</kbd><span>pause</span>';
 $('stage-title').hidden=false;$('game-objective').hidden=true;$('live-hud').hidden=true;$('exercise-badge').hidden=true;$('memory-pads').hidden=true;
 updateScience();beep();
}
function setMode(mode){inputMode=mode;keys.clear();game.updateInput({x:0,y:0,shield:false,relative:mode==='keyboard'});$('input-badge').innerHTML=`${icon(mode==='motion'?'body':'grid',13)} ${mode==='motion'?'BODY CONTROL':'KEYBOARD MODE'}`;$('control-title').textContent=mode==='motion'?'Your movement is connected.':'Move naturally. Play differently.';}
function launch(){
 if(active())return;
 if(inputMode==='motion'&&(!calibrated||cameraState!=='tracking')){toast('Hold a neutral pose until calibration completes.');return;}
 if(inputMode==='motion'&&selected==='exercise'&&!fullBody){toast('Step back until your hips, knees and ankles are visible.');return;}
 savingResult=false;exerciseType='squat';body.setExercise(exerciseType);lastShield=false;keys.clear();
 game.start(selected,{exerciseTarget:12});$('game-canvas').focus({preventScroll:true});beep();
}
function renderState(s){
 snapshot=s;
 const live=['running','paused'].includes(s.status);
 $('stage-title').hidden=live||s.status==='complete';$('live-hud').hidden=!live;$('game-objective').hidden=!live;$('idle-stage-bottom').hidden=live;
 $('launch').hidden=live;$('launch-react').hidden=live;$('pause-button').hidden=!live;$('pause-button').innerHTML=`${s.status==='paused'?'Resume mission':'Pause mission'} ${icon(s.status==='paused'?'play':'pause',18)}`;
 $('pause-overlay').hidden=s.status!=='paused';
 if(!live)return;
 const sec=Math.max(0,Math.ceil(s.timeLeft||0));$('hud-time').textContent=`${String(Math.floor(sec/60)).padStart(2,'0')}:${String(sec%60).padStart(2,'0')}`;
 $('hud-score').textContent=String(Math.round(s.score||0)).padStart(4,'0');$('hud-hull').textContent=`${Math.round(s.hull??100)}%`;
 $('objective-text').textContent=s.objective||mission().objective;$('objective-detail').textContent=s.detail||mission().control;$('mission-progress-fill').style.width=`${Math.min(100,(s.progress||0)*100)}%`;
 $('launch-label').textContent=`MISSION IN PROGRESS / ${inputMode==='motion'?'BODY CONTROL':'KEYBOARD'}`;$('launch-title').textContent=selected==='exercise'?'Every movement powers the mission.':'Find your flow. Stay in control.';$('launch-description').textContent=mission().control;
 $('exercise-badge').hidden=selected!=='exercise';
 if(selected==='exercise'){
  const reps=s.reps||0,type=reps<4?'squat':reps<8?'knee':'reach';if(type!==exerciseType){exerciseType=type;body.setExercise(type);toast(`Next movement: ${type==='knee'?'alternating knee lifts':'overhead reaches'}`);}
  $('exercise-name').textContent=type==='squat'?'SQUAT & RISE':type==='knee'?'ALTERNATING KNEES':'OVERHEAD REACH';$('exercise-count').innerHTML=`${Math.min(4,reps%4)} <small>/ 4</small>`;$('exercise-note').textContent=inputMode==='motion'?'Complete each movement, then return to neutral.':'Keyboard practice · E simulates one rep';
 }
 $('memory-pads').hidden=selected!=='memory';
 if(selected==='memory'){
  const dirs=['left','up','down','right'];const lit=s.sequencePhase==='showing'||s.sequencePhase==='show'?s.sequence?.[s.showIndex]:null;
  document.querySelectorAll('[data-pad]').forEach((el,i)=>{el.classList.toggle('lit',typeof lit==='number'?lit===i:lit===dirs[i]);});
 }
}
function handleGameEvent(event){if(event.type==='toast')toast(event.message);if(event.type==='complete')showResult(event.result||snapshot);}
function pause(reason='Your ship is holding position.'){
 if(snapshot?.status!=='running')return;keys.clear();game.updateInput({x:0,y:0,shield:false});$('pause-reason').textContent=reason;game.pause();
}
function resume(){if(inputMode==='motion'&&(cameraState!=='tracking'||!calibrated)){toast('Restore body tracking or choose Use keyboard before resuming.');return;}game.resume();$('game-canvas').focus({preventScroll:true});}
function handleBodyInput(input){
 if(inputMode!=='motion')return;
 if(!input.tracked){game.updateInput({x:0,y:0,shield:false});return;}
 game.updateInput({x:Math.max(-1,Math.min(1,input.x*settings.sensitivity)),y:Math.max(-1,Math.min(1,input.y*settings.sensitivity)),shield:input.shield,relative:false});
 if(active()&&snapshot.status==='running'){
  if(selected==='exercise'&&input.rep===exerciseType){game.action('rep');beep('rep');}
  if(selected==='memory'&&input.shield&&!lastShield){const {x,y}=input;if(Math.max(Math.abs(x),Math.abs(y))>.26){game.action(Math.abs(x)>Math.abs(y)?x<0?'left':'right':y>0?'up':'down');}else toast('Lean toward a direction, then raise your arms to confirm.');}
 }
 lastShield=!!input.shield;
}
function handleBodyStatus(status){
 cameraState=status.state;
 $('camera-status-pill').textContent=({off:'OFFLINE',starting:'CONNECTING',ready:'READY',calibrating:'CALIBRATING',tracking:'CONNECTED',lost:'NO POSE',error:'UNAVAILABLE'})[status.state]||status.state.toUpperCase();
 $('camera-status-pill').classList.toggle('connected',status.state==='tracking');
 $('tracking-message').textContent=status.message||'Camera processing stays on this device.';
 $('tracking-title').textContent=({off:'Make the connection.',starting:'Opening your body link…',calibrating:'Hold your neutral pose.',tracking:'You are the controller.',lost:'Step back into view.',error:'Body link unavailable.'})[status.state]||'Establishing body link.';
 $('preview-status').textContent=({off:'AWAITING CONNECTION',starting:'STARTING LOCAL VISION',calibrating:'CALIBRATING NEUTRAL POSE',tracking:'LIVE · LOCAL PROCESSING',lost:'TRACKING INTERRUPTED',error:'CAMERA UNAVAILABLE'})[status.state]||'LOCAL PROCESSING';
 if(status.state==='lost'||status.state==='error'){if(inputMode==='motion')pause('Body tracking was interrupted. Restore your pose or switch to keyboard.');}
 if(status.state==='error'){cameraActive=false;calibrated=false;fullBody=false;setMode('keyboard');if(snapshot?.status==='paused')$('pause-reason').textContent='The camera is unavailable. Keyboard controls are ready; resume when you are ready.';renderBodyMetrics({fps:0,confidence:0,fullBody:false,calibrated:false});$('enable-camera').disabled=false;$('enable-camera').hidden=false;$('camera-actions').hidden=true;$('camera-video').hidden=true;$('pose-overlay').hidden=true;$('camera-placeholder').hidden=false;}
 if(status.state==='tracking'&&cameraActive){$('camera-video').hidden=false;$('pose-overlay').hidden=false;$('camera-placeholder').hidden=true;}
}
function renderBodyMetrics(metrics){calibrated=!!metrics.calibrated;fullBody=!!metrics.fullBody;$('pose-points').innerHTML=`${metrics.fullBody?'33':metrics.confidence>0?'TORSO':'—'} <small>${metrics.fullBody?'/ 33':''}</small>`;$('tracking-fps').innerHTML=`${Math.round(metrics.fps||0)} <small>FPS</small>`;$('body-view').textContent=metrics.fullBody?'FULL':metrics.confidence>0?'UPPER':'—';}
async function enableCamera(){
 pause('Setting up body tracking. Hold a neutral pose to calibrate, then resume.');
 $('enable-camera').disabled=true;
 try{const started=await body.start();if(!started){cameraActive=false;setMode('keyboard');toast('Body link could not start. Keyboard mode is ready.');return;}cameraActive=true;setMode('motion');$('enable-camera').hidden=true;$('camera-actions').hidden=false;$('camera-video').hidden=false;$('pose-overlay').hidden=false;$('camera-placeholder').hidden=true;toast('Body link enabled. Hold a relaxed neutral pose to calibrate.');}
 catch(error){toast(error.message||'Camera unavailable. Keyboard mode is ready.');setMode('keyboard');}
 finally{$('enable-camera').disabled=false;}
}
function disconnect(){if(inputMode==='motion')pause('Camera disconnected. You can continue with the keyboard.');body.stop();cameraActive=false;calibrated=false;fullBody=false;setMode('keyboard');$('enable-camera').hidden=false;$('camera-actions').hidden=true;$('camera-video').hidden=true;$('pose-overlay').hidden=true;$('camera-placeholder').hidden=false;$('pose-points').innerHTML='— <small>/ 33</small>';$('tracking-fps').innerHTML='— <small>FPS</small>';$('body-view').textContent='—';}
function showResult(result){
 if(savingResult)return;savingResult=true;
 const summary=summarizeResult(result,inputMode);if(settings.history){history=addSession(history,summary);storage.set('human-exe-history',JSON.stringify(history));$('session-total').textContent=history.length.toString().padStart(2,'0');}
 const success=result.stats?.success||result.progress>=1;
 $('result-dialog').innerHTML=`<button class="dialog-close icon-button" aria-label="Close results">${icon('close')}</button><div class="result-emblem">${icon(success?'check':'orbit',38)}</div><span class="eyebrow">${success?'MISSION ACCOMPLISHED':'SESSION COMPLETE'}</span><h2>${success?'A leap well taken.':'Every flight is progress.'}</h2><p>${escape(mission().name)} · ${inputMode==='motion'?'Body control':'Keyboard practice'}</p><div class="result-stats"><div><b>${summary.score.toLocaleString()}</b><span>ENERGY SCORE</span></div><div><b>${selected==='exercise'?summary.reps:selected==='memory'?(result.stats?.correct||0):summary.hull+'%'}</b><span>${selected==='exercise'?(inputMode==='motion'?'TRACKED REPS':'PRACTICE REPS'):selected==='memory'?'CORRECT SIGNALS':'SHIP INTEGRITY'}</span></div></div><p class="result-note">${settings.history?'Saved to your local flight log.':'History is off. This result has not been saved.'} Gameplay results describe this session, not your health.</p><button class="primary-button" id="replay">Fly again ${icon('arrow',18)}</button><button class="text-button" id="result-next">Choose another mission</button>`;
 $('result-dialog').showModal();$('result-dialog').querySelector('.dialog-close').onclick=closeResult;$('result-next').onclick=closeResult;$('replay').onclick=()=>{closeResult();launch();};beep('complete');
}
function closeResult(){$('result-dialog').close();selectMission(selected);}
function changeView(view){if(active())pause('Mission paused while you explore the dashboard.');currentView=view;['missions','history','guide','settings'].forEach(v=>{$(`${v}-view`).hidden=v!==view;});document.querySelectorAll('[data-view]').forEach(el=>el.classList.toggle('active',el.dataset.view===view));$('breadcrumb').textContent=({missions:'MISSION CONTROL',history:'FLIGHT LOG',guide:'FIELD GUIDE',settings:'SETTINGS'})[view];if(view==='history')renderHistory();if(view==='guide')renderGuide();if(view==='settings')renderSettings();}
function renderHistory(){
 $('history-view').innerHTML=`<div class="eyebrow">YOUR EXPLORATION, ON RECORD</div><h1>Flight log<span>.</span></h1><p class="view-intro">Session scores and movement counts saved on this device.</p><div class="view-toolbar"><span>${history.length} / 30 local sessions · ${settings.history?'saving enabled':'saving disabled'}</span><div><button class="outline-button" id="export-history">${icon('download',16)} Export history</button><button class="outline-button" id="delete-history">${icon('trash',16)} Delete history</button></div></div>${history.length?`<div class="history-table"><table><thead><tr><th>MISSION</th><th>DATE</th><th>CONTROLS</th><th>SCORE</th><th>REPS</th></tr></thead><tbody>${history.map(s=>`<tr><td>${escape(missions.find(m=>m.id===s.mission)?.name||s.mission)}</td><td>${new Date(s.timestamp).toLocaleString()}</td><td>${escape(s.inputMode)}</td><td>${s.score.toLocaleString()}</td><td>${s.reps||'—'}</td></tr>`).join('')}</tbody></table></div>`:`<div class="empty-state">${icon('orbit',64)}<h2>Your story starts with a flight.</h2><p>Enable local history in Settings to keep future mission results.</p><button class="primary-button" id="history-settings">Open settings ${icon('arrow',17)}</button></div>`}`;
 $('export-history').onclick=()=>{const blob=new Blob([JSON.stringify({game:'HUMAN.exe Orbital',version:1,exportedAt:new Date().toISOString(),sessions:history},null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='HUMAN-exe-flight-log.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);};
 $('delete-history').onclick=()=>{history=[];storage.remove('human-exe-history');$('session-total').textContent='00';renderHistory();toast('All saved session results were deleted from this device.');};$('history-settings')?.addEventListener('click',()=>changeView('settings'));
}
function renderGuide(){
 $('guide-view').innerHTML=`<div class="eyebrow">KNOW YOUR MISSION</div><h1>A human in orbit<span>.</span></h1><p class="view-intro">The science behind the play, and the movements that make it possible.</p><div class="guide-grid">${missions.map(m=>{const c=nasa?.contexts?.[m.id];return `<article class="guide-card"><span class="mission-icon">${icon(m.icon,25)}</span><div class="eyebrow">${m.tag}</div><h2>${escape(c?.title||m.name)}</h2><p>${escape(c?.text||m.desc)}</p><div class="guide-control">${escape(m.control)}</div>${(c?.sourceIds||[]).map(id=>{const source=nasa.sources.find(s=>s.id===id);return source?`<a href="${escape(source.url)}" target="_blank" rel="noopener noreferrer">${escape(source.title)} ↗</a>`:'';}).join('')}</article>`;}).join('')}</div><div class="guide-footnote"><h3>Move with awareness.</h3><p>Use a clear space and comfortable, controlled movements. Seated steering is available. Lower-body tracking needs your hips, knees and ankles in frame. This game does not prescribe exercise, measure bone or muscle health, diagnose conditions, or replace astronaut resistance equipment.</p><button class="outline-button" id="guide-controls">${icon('body',17)} Open control guide</button></div>`;
 $('guide-controls').onclick=showHelp;
}
function renderSettings(){
 $('settings-view').innerHTML=`<div class="eyebrow">MAKE SPACE YOURS</div><h1>Flight preferences<span>.</span></h1><p class="view-intro">Simple controls. Clear choices. All processing stays on this device.</p><div class="settings-list"><div class="setting-row"><div><h3>Mission audio</h3><p>Subtle synthesized feedback for actions and completed missions.</p></div><label class="switch"><input id="setting-sound" type="checkbox" ${settings.sound?'checked':''} aria-label="Mission audio"><span></span></label></div><div class="setting-row"><div><h3>Save local flight history</h3><p>Keep up to 30 derived session summaries. No images, video or body landmarks are saved.</p></div><label class="switch"><input id="setting-history" type="checkbox" ${settings.history?'checked':''} aria-label="Save local flight history"><span></span></label></div><div class="setting-row"><div><h3>Movement sensitivity</h3><p>Adjust steering response after calibrating your neutral pose.</p></div><div class="range-setting"><input id="setting-sensitivity" type="range" min="0.5" max="2" step="0.1" value="${settings.sensitivity}" aria-label="Movement sensitivity"><output id="sensitivity-value">${Number(settings.sensitivity).toFixed(1)}×</output></div></div><div class="setting-row"><div><h3>Camera controls</h3><p>Camera permission is separate from local history. Disconnect to release the camera.</p></div><button class="outline-button" id="settings-camera">${icon('camera',17)} ${cameraActive?'Disconnect camera':'Enable camera'}</button></div></div><div class="guide-footnote"><h3>Your privacy, by design.</h3><p>OpenCV and MediaPipe process webcam frames locally. The game has no account, server upload, facial identity recognition or medical assessment. The flight log can be exported or deleted at any time.</p></div>`;
 $('setting-sound').onchange=e=>{settings.sound=e.target.checked;saveSettings();beep();};$('setting-history').onchange=e=>{settings.history=e.target.checked;saveSettings();};$('setting-sensitivity').oninput=e=>{settings.sensitivity=Number(e.target.value);$('sensitivity-value').textContent=settings.sensitivity.toFixed(1)+'×';saveSettings();};$('settings-camera').onclick=()=>{cameraActive?disconnect():enableCamera();changeView('missions');};
}
function saveSettings(){storage.set('human-exe-settings',JSON.stringify(settings));$('sound-toggle').classList.toggle('sound-enabled',settings.sound);$('sound-toggle').setAttribute('aria-label',settings.sound?'Disable sound':'Enable sound');}
function updateScience(){const c=nasa?.contexts?.[selected];if(c)$('science-summary').textContent=c.text.length>155?c.text.slice(0,152).replace(/\s+\S*$/,'')+'…':c.text;}
function showHelp(){
 pause('Mission paused while the control guide is open.');
 $('help-dialog').innerHTML=`<button class="dialog-close icon-button" aria-label="Close control guide">${icon('close')}</button><span class="eyebrow">YOU ARE THE CONTROLLER</span><h2>A little movement.<br>A whole new world.</h2><div class="help-columns"><div><h3>${icon('body')} Body control</h3><p>Enable tracking. Face the camera and hold a relaxed neutral pose for two seconds. Recalibrate whenever you change position.</p><ul><li>Lean left / right to steer horizontally.</li><li>Lean forward / back to steer vertically.</li><li>Raise both arms to activate the shield.</li><li>For memory: lean toward a direction, then raise arms to confirm.</li><li>For exercise: keep your full body visible and complete each movement before returning to neutral.</li></ul></div><div><h3>${icon('grid')} Keyboard</h3><ul><li><kbd>W A S D</kbd> or <kbd>ARROWS</kbd> steer.</li><li><kbd>SPACE</kbd> activates the shield.</li><li>Memory: directional keys enter the sequence directly. <kbd>SPACE</kbd> repeats the last selected direction.</li><li><kbd>E</kbd> simulates an exercise rep in keyboard practice.</li><li><kbd>P</kbd> pauses or resumes.</li></ul><p>Camera loss, leaving the tab, or opening another panel pauses active play.</p></div></div><div class="guide-footnote"><p>Zero-G circuit: 4 squat-and-rise cycles, 4 alternating knee lifts, 4 reach-and-lower cycles. Actual astronaut exercise uses prescribed resistive and aerobic equipment; this is a movement game.</p></div>`;
 $('help-dialog').showModal();$('help-dialog').querySelector('.dialog-close').onclick=()=>$('help-dialog').close();
}

document.querySelectorAll('[data-mission]').forEach(el=>el.onclick=()=>selectMission(el.dataset.mission));
document.querySelectorAll('[data-view]').forEach(el=>el.onclick=()=>changeView(el.dataset.view));
document.querySelector('.brand').onclick=e=>{e.preventDefault();changeView('missions');};
$('launch').onclick=launch;$('enable-camera').onclick=enableCamera;$('camera-off').onclick=disconnect;$('recalibrate').onclick=()=>{pause('Recalibrating your neutral pose.');body.calibrate();setMode('motion');};$('keyboard-mode').onclick=()=>{pause('Keyboard mode selected. Resume when ready.');setMode('keyboard');toast('Keyboard controls are ready.');};
$('pause-button').onclick=()=>snapshot?.status==='paused'?resume():pause();$('resume').onclick=resume;$('end-mission').onclick=()=>game.end();
$('choose-exercise').onclick=()=>{changeView('missions');selectMission('exercise');$('flight-stage').scrollIntoView({behavior:'smooth',block:'center'});};
$('controls-help').onclick=showHelp;$('science-more').onclick=()=>changeView('guide');$('crew-guide').onclick=()=>changeView('guide');$('open-history').onclick=()=>changeView('history');
$('sound-toggle').onclick=()=>{settings.sound=!settings.sound;saveSettings();if(settings.sound)beep();toast(settings.sound?'Mission audio enabled.':'Mission audio muted.');};
$('fullscreen').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await $('flight-stage').requestFullscreen();}catch{toast('Full screen is unavailable in this browser.');}};
document.addEventListener('visibilitychange',()=>{if(document.hidden)pause('Mission paused while the game tab is hidden.');});window.addEventListener('blur',()=>pause('Mission paused because the game lost focus.'));
$('game-canvas').addEventListener('keydown',event=>{
 if(!active()||event.repeat)return;const key=event.key.toLowerCase();if([' ','arrowleft','arrowright','arrowup','arrowdown','w','a','s','d','p','e'].includes(key))event.preventDefault();
 if(key==='p'){snapshot.status==='paused'?resume():pause();return;}
 if(snapshot.status!=='running'||inputMode!=='keyboard')return;
 keys.add(key);const dir=({arrowleft:'left',a:'left',arrowup:'up',w:'up',arrowdown:'down',s:'down',arrowright:'right',d:'right'})[key];
 if(selected==='memory'&&dir){heldDirection=dir;game.action(dir);beep();}else if(key===' '){game.action(selected==='memory'?heldDirection:'shield');beep();}else if(key==='e'&&selected==='exercise'){game.action('rep');beep('rep');}
 updateKeyboard();
});
window.addEventListener('keyup',event=>{keys.delete(event.key.toLowerCase());if(inputMode==='keyboard')updateKeyboard();});
$('game-canvas').addEventListener('blur',()=>{keys.clear();if(inputMode==='keyboard')game.updateInput({x:0,y:0,shield:false});});
function updateKeyboard(){if(!active()||inputMode!=='keyboard')return;game.updateInput({x:Number(keys.has('d')||keys.has('arrowright'))-Number(keys.has('a')||keys.has('arrowleft')),y:Number(keys.has('w')||keys.has('arrowup'))-Number(keys.has('s')||keys.has('arrowdown')),shield:keys.has(' '),relative:true});}
fetch('/data/nasa-reference.json').then(r=>{if(!r.ok)throw Error();return r.json();}).then(data=>{nasa=data;updateScience();if(currentView==='guide')renderGuide();}).catch(()=>toast('Science reference could not load. Gameplay is available.'));
saveSettings();
