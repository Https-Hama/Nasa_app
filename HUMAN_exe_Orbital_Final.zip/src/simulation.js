const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const durations = { asteroids: 60, memory: 90, docking: 60, exercise: 120 };
const directions = ['left', 'up', 'right', 'down'];

/** Deterministic mission rules, kept independent of graphics and camera hardware. */
export class OrbitSimulation {
  constructor({ random = Math.random, onEvent = () => {} } = {}) {
    this.random = random;
    this.onEvent = onEvent;
    this.preview('asteroids');
  }

  start(mission = 'asteroids', options = {}) {
    if (!Object.hasOwn(durations, mission)) throw new RangeError(`Unknown mission: ${mission}`);
    this.duration = Number.isFinite(options.duration) ? clamp(options.duration, 0.1, 3600) : durations[mission];
    this.exerciseTarget = Math.round(clamp(Number(options.exerciseTarget) || 12, 1, 200));
    this.ship = { x: 0, y: 0 };
    this.input = { x: 0, y: 0, shield: false, relative: false };
    this.dockTarget = { x: 0, y: 1.1 };
    this.entities = [];
    this.entityId = 0;
    this.spawnAt = 1.4;
    this.elapsed = 0;
    this.invulnerable = 0;
    this.shieldPulse = 0;
    this.impact = 0;
    this.repPulse = 0;
    this.phaseTime = 0;
    this.lastAnswerAt = 0;
    this.completed = false;
    this.state = {
      mission, status: 'running', timeLeft: this.duration, score: 0, hull: 100,
      shield: 100, combo: 1, progress: 0, objective: '', detail: '', reps: 0,
      sequence: mission === 'memory' ? ['left', 'up', 'right'] : [],
      sequencePhase: mission === 'memory' ? 'showing' : 'idle', memoryIndex: 0,
      dockPrecision: 0,
      stats: {
        collisions: 0, dodged: 0, collected: 0, shieldBlocks: 0,
        correct: 0, attempts: 0, rounds: 0, reactionTimes: [], averageReaction: 0,
        accuracy: 0, success: false, reason: '', exerciseTarget: this.exerciseTarget,
        shieldActive: false, elapsed: 0, alignmentTime: 0,
      },
    };
    if (mission === 'asteroids') {
      for (let i = 0; i < 12; i += 1) this.spawnEntity(-38 - i * 18, i % 4 === 3 ? 'pickup' : 'asteroid');
    }
    this.describe();
    return this.snapshot();
  }

  preview(mission = 'asteroids') {
    this.start(mission);
    this.state.status = 'ready';
    return this.snapshot();
  }

  updateInput(input = {}) {
    this.input = {
      x: Number.isFinite(input.x) ? clamp(input.x, -1, 1) : 0,
      y: Number.isFinite(input.y) ? clamp(input.y, -1, 1) : 0,
      shield: Boolean(input.shield),
      relative: typeof input.relative === 'boolean' ? input.relative : this.input.relative,
    };
  }

  action(action) {
    const state = this.state;
    if (state.status !== 'running') return;
    if (action === 'shield') {
      if (state.shield > 8) this.shieldPulse = 0.85;
      return;
    }
    if (state.mission === 'exercise' && action === 'rep') {
      state.reps += 1;
      state.score += 150;
      state.combo = Math.min(8, 1 + Math.floor(state.reps / 3));
      state.progress = state.reps / this.exerciseTarget;
      this.repPulse = 1;
      this.onEvent({ type: 'toast', message: `REP ${state.reps} / ${this.exerciseTarget} · ENERGY RESTORED` });
      if (state.reps >= this.exerciseTarget) this.finish(true, 'goal');
      this.describe();
      return;
    }
    if (state.mission !== 'memory' || state.sequencePhase !== 'input' || !directions.includes(action)) return;
    const stats = state.stats;
    stats.attempts += 1;
    const correct = action === state.sequence[state.memoryIndex];
    if (correct) stats.correct += 1;
    stats.accuracy = Math.round(stats.correct / stats.attempts * 100);
    if (correct) {
      stats.reactionTimes.push(Math.round((this.elapsed - this.lastAnswerAt) * 1000));
      stats.averageReaction = Math.round(stats.reactionTimes.reduce((sum, time) => sum + time, 0) / stats.reactionTimes.length);
      state.memoryIndex += 1;
      state.combo = Math.min(8, state.combo + 1);
      state.score += 80 + 20 * state.combo;
      this.lastAnswerAt = this.elapsed;
      if (state.memoryIndex === state.sequence.length) {
        stats.rounds += 1;
        state.progress = stats.rounds / 3;
        if (stats.rounds === 3) this.finish(true, 'goal');
        else {
          state.sequence = [...state.sequence, stats.rounds === 1 ? 'down' : 'left'];
          state.sequencePhase = 'showing';
          state.memoryIndex = 0;
          this.phaseTime = -0.6;
          this.onEvent({ type: 'toast', message: `SEQUENCE VERIFIED · ROUND ${stats.rounds + 1}` });
        }
      }
    } else {
      state.hull = Math.max(0, state.hull - 18);
      state.combo = 1;
      state.memoryIndex = 0;
      state.sequencePhase = 'showing';
      this.phaseTime = -0.5;
      this.impact = 1;
      this.onEvent({ type: 'toast', message: 'SIGNAL MISMATCH · WATCH THE SEQUENCE AGAIN' });
      if (state.hull <= 0) this.finish(false, 'hull');
    }
    this.describe();
  }

  tick(seconds) {
    if (this.state.status !== 'running' || !Number.isFinite(seconds) || seconds <= 0) return;
    // Small physical steps prevent a slow frame from tunnelling through an asteroid.
    let remaining = Math.min(seconds, 3600);
    while (remaining > 0.000001 && this.state.status === 'running') {
      const dt = Math.min(remaining, 0.05, this.state.timeLeft);
      this.step(dt);
      remaining -= dt;
      if (this.state.timeLeft <= 0.000001) {
        this.state.timeLeft = 0;
        this.finish(this.state.mission === 'asteroids' && this.state.hull > 0, 'time');
      }
    }
    this.describe();
  }

  step(dt) {
    const state = this.state;
    this.elapsed += dt;
    state.timeLeft = Math.max(0, this.duration - this.elapsed);
    state.stats.elapsed = this.elapsed;
    if (this.input.relative) {
      this.ship.x = clamp(this.ship.x + this.input.x * 3.5 * dt, -5.2, 5.2);
      this.ship.y = clamp(this.ship.y + this.input.y * 2.7 * dt, -3.4, 3.4);
    } else {
      this.ship.x += (this.input.x * 5.2 - this.ship.x) * (1 - Math.exp(-7 * dt));
      this.ship.y += (this.input.y * 3.4 - this.ship.y) * (1 - Math.exp(-7 * dt));
    }
    this.invulnerable = Math.max(0, this.invulnerable - dt);
    this.shieldPulse = Math.max(0, this.shieldPulse - dt);
    this.impact = Math.max(0, this.impact - dt * 2.5);
    this.repPulse = Math.max(0, this.repPulse - dt * 1.5);
    const shieldRequested = (this.input.shield || this.shieldPulse > 0) && state.shield > 0;
    state.stats.shieldActive = shieldRequested;
    state.shield = clamp(state.shield + (shieldRequested ? -13 : 8) * dt, 0, 100);

    if (state.mission === 'asteroids') this.stepFlight(dt);
    if (state.mission === 'memory') {
      this.phaseTime += dt;
      if (state.sequencePhase === 'showing' && this.phaseTime >= state.sequence.length * 0.9 + 0.5) {
        state.sequencePhase = 'input';
        this.lastAnswerAt = this.elapsed;
      }
    }
    if (state.mission === 'docking') {
      this.dockTarget.x = Math.sin(this.elapsed * 0.32) * 2;
      this.dockTarget.y = Math.cos(this.elapsed * 0.27) * 1.1;
      const distance = Math.hypot(this.ship.x - this.dockTarget.x, this.ship.y - this.dockTarget.y);
      state.dockPrecision = clamp(100 - distance * 28, 0, 100);
      const aligned = state.dockPrecision >= 85;
      state.progress = clamp(state.progress + (aligned ? dt / 10 : -dt / 7), 0, 1);
      if (aligned) {
        state.stats.alignmentTime += dt;
        state.score += dt * state.dockPrecision;
      }
      if (state.progress >= 0.999999) {
        state.progress = 1;
        this.finish(true, 'goal');
      }
    }
  }

  spawnEntity(z, type = 'asteroid') {
    this.entities.push({
      id: ++this.entityId, type, z,
      x: (this.random() - 0.5) * 10.5,
      y: (this.random() - 0.5) * 6.5,
      radius: type === 'asteroid' ? 0.85 + this.random() * 0.8 : 0.65,
      rotation: this.random() * Math.PI * 2,
      checked: false, removed: false,
    });
  }

  stepFlight(dt) {
    const state = this.state;
    state.score += dt * 8;
    state.progress = clamp(this.elapsed / this.duration, 0, 1);
    this.spawnAt -= dt;
    if (this.spawnAt <= 0) {
      this.spawnEntity(-170, this.random() > 0.76 ? 'pickup' : 'asteroid');
      this.spawnAt = Math.max(0.65, 1.4 - this.elapsed / 180);
    }
    const speed = 19 + this.elapsed * 0.055;
    for (const entity of this.entities) {
      entity.z += dt * speed;
      entity.rotation += dt * 0.25;
      if (!entity.checked && entity.z >= 2.5 - entity.radius && entity.z <= 5 + entity.radius) {
        const distance = Math.hypot(entity.x - this.ship.x, entity.y - this.ship.y);
        if (distance < entity.radius + 0.7) {
          entity.checked = true;
          entity.removed = true;
          if (entity.type === 'pickup') {
            state.stats.collected += 1;
            state.score += 120 * state.combo;
            state.combo = Math.min(8, state.combo + 1);
            state.shield = Math.min(100, state.shield + 15);
            this.repPulse = 0.7;
            this.onEvent({ type: 'toast', message: `ENERGY CAPTURED · ×${state.combo} COMBO` });
          } else if (this.invulnerable <= 0) {
            state.stats.collisions += 1;
            this.invulnerable = 0.85;
            if (state.stats.shieldActive && state.shield >= 12) {
              state.shield -= 12;
              state.stats.shieldBlocks += 1;
              state.score += 25;
              this.onEvent({ type: 'toast', message: 'SHIELD ABSORBED IMPACT' });
            } else {
              state.hull = Math.max(0, state.hull - 28);
              state.combo = 1;
              this.impact = 1;
              this.onEvent({ type: 'toast', message: 'HULL IMPACT · STEER CLEAR OF THE ROCKS' });
              if (state.hull <= 0) this.finish(false, 'hull');
            }
          }
        }
      }
      if (entity.z > 6 + entity.radius && !entity.checked) {
        entity.checked = true;
        if (entity.type === 'asteroid') {
          state.stats.dodged += 1;
          state.score += 20;
        }
      }
    }
    this.entities = this.entities.filter(entity => !entity.removed && entity.z < 24);
  }

  pause() {
    if (this.state.status === 'running') this.state.status = 'paused';
    return this.snapshot();
  }

  resume() {
    if (this.state.status === 'paused') this.state.status = 'running';
    return this.snapshot();
  }

  end() {
    if (this.state.status === 'running' || this.state.status === 'paused') this.finish(false, 'ended');
    return this.snapshot();
  }

  finish(success, reason) {
    if (this.completed) return;
    this.completed = true;
    this.state.status = 'complete';
    this.state.stats.success = success;
    this.state.stats.reason = reason;
    this.state.stats.shieldActive = false;
    if (success) {
      this.state.score += Math.round(this.state.hull * 5);
      this.state.progress = 1;
    }
    this.describe();
    this.onEvent({ type: 'complete', result: this.snapshot() });
  }

  describe() {
    const state = this.state;
    if (state.mission === 'asteroids') {
      state.objective = 'Navigate the asteroid field';
      state.detail = 'Steer around rocks · collect cyan energy · raise your shield';
    } else if (state.mission === 'memory') {
      state.objective = `Signal sequence · ${Math.min(3, state.stats.rounds + 1)} / 3`;
      state.detail = state.sequencePhase === 'showing' ? 'Watch the illuminated directions, then repeat them' : `Repeat the pattern · ${state.memoryIndex} / ${state.sequence.length} received`;
    } else if (state.mission === 'docking') {
      state.objective = 'Align with the orbital station';
      state.detail = state.dockPrecision >= 85 ? `${Math.round(state.dockPrecision)}% precision · alignment locked, hold steady` : `${Math.round(state.dockPrecision)}% precision · align the orange cursor with the cyan beacon, above 85%`;
    } else {
      state.objective = `Training circuit · ${state.reps} / ${this.exerciseTarget} reps`;
      const group = Math.min(2, Math.floor(state.reps / Math.max(1, this.exerciseTarget / 3)));
      state.detail = ['Squats · lower, then return to standing', 'Knee lifts · lift one knee, then lower it', 'Overhead reaches · raise both arms, then lower'][group];
    }
    if (state.status === 'complete') state.detail = state.stats.success ? 'Objective complete · return to mission control for your debrief' : state.stats.reason === 'ended' ? 'Session ended · your completed activity is in the debrief' : 'Session complete · review your flight and try again';
  }

  snapshot() {
    const state = this.state;
    const showIndex = state.sequencePhase === 'showing' && this.phaseTime >= 0 && this.phaseTime % 0.9 < 0.65 ? Math.floor(this.phaseTime / 0.9) : -1;
    return {
      ...state, score: Math.round(state.score), hull: Math.round(state.hull), shield: Math.round(state.shield),
      dockPrecision: Math.round(state.dockPrecision), sequence: [...state.sequence],
      showIndex: showIndex < state.sequence.length ? showIndex : -1,
      dockTarget: { ...this.dockTarget },
      stats: { ...state.stats, reactionTimes: [...state.stats.reactionTimes] },
    };
  }
}
