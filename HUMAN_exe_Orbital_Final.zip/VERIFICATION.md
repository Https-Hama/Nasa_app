# HUMAN.exe Orbital verification

Verified on 14 November 2026 in this Windows workspace.

## Automated checks

- **28 Node tests pass:** pose confidence and framing, neutral calibration, mirrored steering, dead zone, completed squat/knee/reach cycles, held-pose rejection, cooldown, tracking interruption, camera denial, session-data filtering/history cap, mission lifecycle, collisions and shield, energy collection, failure, pause, relative keyboard steering, memory progression and final metrics, docking, exercise completion, mission preview and once-only completion.
- **8 browser journeys pass in installed Chrome:** dashboard, actual React Bits elements, camera permission denial and fallback, complete 4+4+4 exercise circuit, pause freezing time and input, result dialog/replay reset, history save/export/delete, directional memory progression, docking launch/steering, asteroid flight/shield, navigation pause, field guide and control guide, and responsive layouts at 768px and 390px without horizontal overflow.
- **Zero page or console errors** in the completed browser journey.
- **Runtime camera-disconnection regression passes:** an ended event on a live synthetic camera track releases the stream, automatically restores keyboard mode and allows the paused production mission to resume without a camera.
- **Real local camera pipeline smoke:** synthetic Chrome camera stream initialized OpenCV and the bundled pose model, processed frames through OpenCV, ran local pose inference, correctly reported no person and tracking loss, then released the video stream and model when stopped. This verifies the processing path, not human movement accuracy.
- **Production build:** Vite generates the bundled game in `dist`. All models, WASM, OpenCV and custom artwork are local assets. No runtime CDN is required.

The full browser journey and camera smoke also pass against the production launcher at localhost port 4173. Visual inspection covered desktop, phone, gameplay and the result dialog. Fixed a React Bits glow that widened small-screen pages, a crop mismatch between camera and pose overlay, stale ready-state rendering after a completed mission, and camera transitions so setup pauses gameplay and a runtime failure restores keyboard control.

## Material limits

A real person has not performed the exercise circuit on the intended webcam. Camera-specific detection accuracy, body diversity, lighting robustness, comfortable steering range and actual hardware FPS still require that playtest. Synthetic landmark tests and a synthetic stream cannot establish those qualities.

This is a fictional movement game with research-linked educational context. It is not a medical assessment, validated astronaut exercise program, muscle/bone measurement or substitute for resistance hardware. Keyboard exercise inputs are visibly labeled practice reps. No trained fatigue or diagnostic model is claimed.

The production bundle contains the Three.js renderer as a separate approximately 525 kB uncompressed chunk. Vite reports its standard 500 kB advisory; the build completes successfully and the chunk is approximately 136 kB compressed.
