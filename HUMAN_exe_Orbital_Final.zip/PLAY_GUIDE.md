# HUMAN.exe — Orbital

A local browser game with four space missions, keyboard controls and optional webcam body control. The exercise circuit offers movement goals and rep feedback; it does not measure health, diagnose a condition or establish astronaut fitness.

## Start on Windows

The finished game is already built. On Windows, double-click `START_HUMAN_EXE.cmd`. It starts a local server and opens the game in your browser. Keep its terminal window open while playing. The included production build needs Node.js 22 or newer and no installation or internet connection to play.

To rebuild from source, install Node.js with npm available in your PATH, open this folder in PowerShell and run:

```powershell
npm install
npm run assets
npm run dev
```

Open the localhost address printed by Vite. Keep the terminal open while playing. Alternatively, double-click `START_HUMAN_EXE.cmd` in this folder; the launcher handles setup and starts the local game. Initial installation and asset preparation need an internet connection.

The setup step bundles the camera model, vision runtime and OpenCV assets locally. The game then serves its runtime assets from your own machine. NASA reference links open external pages when selected. Use the localhost server for camera play; opening `index.html` directly is not the supported launch method.

## First flight

1. Choose a mission and use keyboard mode to begin immediately, or select **Enable body tracking** to request access.
2. For camera control, allow the browser's camera prompt. Face the camera with even lighting and a clear view of your body. Keep shoulders and hips visible for steering; show your entire body, including knees and ankles, for lower-body exercises.
3. Stand or sit in your neutral position for automatic two-second calibration. Select **Recalibrate** after moving the camera or changing your position.
4. Start the mission. Use the pause control whenever you need a break. If tracking is lost, restore the pose and resume when the tracker is ready, or switch to keyboard mode.

Choose a comfortable range of movement and clear enough space for the movements you choose. Seated play is available for steering missions; full-body framing is required for squat and knee-lift recognition. The keyboard can complete every mission without a camera.

## Controls

| Action | Body control | Keyboard |
| --- | --- | --- |
| Steer left or right | Lean left or right from the calibrated center | Left/right arrows or A/D |
| Steer vertically | Shift your upper body above or below the calibrated center | Up/down arrows or W/S |
| Shield | Raise both arms | Space |
| Enter a memory direction | Lean toward a direction, then raise both arms | Arrows / WASD submit directly; Space repeats the last direction |
| Complete an exercise movement | Follow the current squat, knee-lift or overhead-reach prompt, then return to neutral | E sends a simulated game rep |

An exercise key press is game input; it does not establish that physical exercise occurred. Hold neither a raised pose nor a bent pose to accumulate reps: the camera counts a completed movement cycle and requires a return toward neutral before another rep.

## Missions

- **Asteroid survival:** steer through the field, avoid impacts and use the shield when needed. Watch hull and shield energy.
- **Memory sequence:** watch the displayed arrows in order. During the response phase, lean toward each remembered direction and confirm with raised arms. With the keyboard, press the arrow or WASD key once to submit each direction directly; no additional confirmation is needed. Repeat for the whole sequence.
- **Docking alignment:** move into the target alignment and hold steady while the docking progress fills.
- **Exercise circuit:** follow the displayed movement type. Complete squats, alternating knee lifts and overhead reaches with a return to neutral between reps. The mission display shows the current target and progress.

Camera inference can be delayed or lose confidence because of lighting, framing, occlusion, clothing or device speed. Rep counts are approximate game events. They are not a form assessment or a measurement of resistance, force, calories, bone density or muscle adaptation.

## Privacy and local history

The game requests camera access only after you select **Enable body tracking**. Video frames are processed in the browser and are not saved or uploaded by the game. Disabling the camera stops the active stream. Browser permission controls can also revoke access.

Local history is optional. When enabled, it stores derived session results in this browser on this machine. Use **Export history** to download those results, or **Delete history** to erase the game's stored history. An exported file is a separate copy; deleting browser history does not delete exported files. No video is included in session exports.

## What the space research means

NASA studies muscle and bone changes, cognition and sensorimotor performance during spaceflight. These topics inform the game's educational notes. The missions are fictional and have not been validated as astronaut training, cognitive tests or medical countermeasures.

In microgravity, a camera cannot supply the mechanical loading that astronauts need for exercise. NASA identifies three distinct ISS devices: ARED provides resistance for weightlifting-like exercise; the T2 treadmill supports running with restraint/loading; and CEVIS is a cycle ergometer for cycling. This game's webcam detects motion only. Its body movements do not replace astronaut exercise hardware, and the game has not been shown to prevent bone or muscle loss. [NASA exercise overview](https://www.nasa.gov/missions/station/iss-research/astronaut-exercise/), [NASA muscle and bone research](https://www.nasa.gov/humans-in-space/counteracting-bone-and-muscle-loss-in-microgravity/).

The game uses an existing MediaPipe pose model with OpenCV frame processing. This project does not train an assessment model and does not perform facial diagnosis, emotion recognition or clinical scoring. Scores, timing and rep counts describe gameplay only. NASA references do not imply NASA endorsement.

## Troubleshooting and verification limits

- **Camera denied or missing:** use keyboard mode. To try again, allow camera access for the localhost page in your browser's site settings and check Windows camera privacy settings.
- **Camera assets fail to load:** stop the server, run `npm run assets`, restart `npm run dev`, and reload the page. The initial asset download needs network access.
- **No reps detected:** move farther from the camera until the full body fits; restore clear lighting; return to neutral between movements and recalibrate. Lower-body recognition requires visible, confident hip, knee and ankle landmarks.
- **Tracking pauses a mission:** return to the frame, check the tracker status and use the resume control. The game also pauses when its tab is hidden.
- **Slow rendering or tracking:** close other camera applications and unnecessary tabs, use a smaller browser window or keyboard mode, and keep the game tab visible.

Real-person webcam accuracy and performance on your particular camera and computer still require a hardware playtest. Automated logic and browser checks cannot establish rep-count accuracy, accessibility for every body or device, exercise benefit, or clinical validity.

## NASA source appendix

Official primary-source pages reviewed on 14 November 2026; the runtime summaries are in `public/data/nasa-reference.json`.

- [Astronaut Exercise](https://www.nasa.gov/missions/station/iss-research/astronaut-exercise/) — equipment and exercise research.
- [Counteracting Bone and Muscle Loss in Microgravity](https://www.nasa.gov/humans-in-space/counteracting-bone-and-muscle-loss-in-microgravity/) — loading, ARED and exercise motivation.
- [Risks of Human Spaceflight](https://www.nasa.gov/hrp/risks/) — HRP health and performance risks.
- [Five Hazards of Human Spaceflight](https://www.nasa.gov/hrp/hazards/) — NASA's hazard categories.
- [Peak Performance in Microgravity](https://www.nasa.gov/missions/station/iss-research/peak-performance-in-microgravity/) — physical and cognitive performance research.
- [Human Research Roadmap: sensorimotor and vestibular risk](https://humanresearchroadmap.nasa.gov/Risks/risk.aspx?i=88) — orientation and manual-control research.
