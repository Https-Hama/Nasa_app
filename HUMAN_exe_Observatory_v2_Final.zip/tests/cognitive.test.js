import test from 'node:test';
import assert from 'node:assert/strict';
import { MindCheck } from '../src/cognitive.js';

test('pattern challenge ignores answers during playback and completes three increasing rounds',()=>{
 const mind=new MindCheck({random:()=>.2});mind.start(0);mind.answer('left',100);assert.equal(mind.snapshot().results.memory.attempts,0);
 let now=0;for(let round=0;round<3;round++){now+=7000;mind.tick(now);const s=mind.snapshot();assert.equal(s.sequence.length,round+3);for(const d of s.sequence)mind.answer(d,now+=200);}
 assert.equal(mind.snapshot().stage,'attention');assert.equal(mind.snapshot().results.memory.correct,12);assert.equal(mind.snapshot().results.memory.rounds,3);
});
test('wrong patterns are recorded and replayed without advancing a round',()=>{
 const mind=new MindCheck();mind.start(0);mind.tick(5000);mind.answer('down',5100);const s=mind.snapshot();assert.equal(s.results.memory.attempts,1);assert.equal(s.results.memory.correct,0);assert.equal(s.round,0);assert.equal(s.phase,'showing');
});
test('focus task measures actual onset reaction time and separates false alarms and misses',()=>{
 const mind=new MindCheck({random:()=>.2});mind.startAttention(0);mind.tick(2000);assert.equal(mind.snapshot().cue,'go');mind.answer('respond',2350);assert.equal(mind.snapshot().results.attention.medianReactionMs,350);
 let now=4000;mind.tick(now);mind.tick(now+=2000);assert.equal(mind.snapshot().cue,'wait');mind.answer('respond',now+100);assert.equal(mind.snapshot().results.attention.falseAlarms,1);
 mind.tick(now+=3000);mind.tick(now+=2000);mind.tick(now+=2000);assert.ok(mind.snapshot().results.attention.misses>=1);
});
test('paused mental tasks ignore input and preserve the stimulus deadline',()=>{
 const mind=new MindCheck();mind.startAttention(0);mind.tick(1000);mind.pause(1100);mind.answer('respond',1200);mind.tick(10000);assert.equal(mind.snapshot().results.attention.attempts,0);mind.resume(10000);mind.tick(10100);assert.equal(mind.snapshot().phase,'stimulus');
});

test('a response after an expired attention cue counts as a miss even before the next animation frame',()=>{
 const mind=new MindCheck();mind.startAttention(0);mind.tick(700);mind.answer('respond',5000);const a=mind.snapshot().results.attention;assert.equal(a.correct,0);assert.equal(a.misses,1);assert.equal(a.medianReactionMs,null);
});
