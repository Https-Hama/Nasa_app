# HUMAN.exe Human Observatory play guide

## Launch

Extract the complete ZIP and double-click START_HUMAN_EXE.cmd. Node.js 22 or newer is required. The production game needs no internet connection after extraction. Keep the launcher terminal open and use its localhost URL. Ctrl+C stops that server.

## Camera controls

Select Enable camera controls and accept the browser permission prompt. Hold a relaxed neutral pose with shoulders and hips visible for calibration. Recalibrate after changing camera distance or position. Use a comfortable, clear space; seated hand controls are available, while leg actions require full-body framing.

Move the left hand to aim. Extend the right arm at shoulder height to fire repeatedly; raise both hands overhead to shield. A completed knee lift followed by lowering triggers a short boost. A completed squat-and-rise cycle triggers a brief duck. Return to neutral between leg actions; held poses do not repeatedly trigger them. These are game-control thresholds, not an exercise-form assessment.

WASD or arrows aim with keyboard controls. Hold J to fire. Space shields; Shift boosts; C ducks; P pauses. Camera loss pauses motion play. A disconnected camera releases the stream and restores keyboard fallback. Controls are only read for the focused game or active mind-check dialog.

## Face and body observations

Observation consent is separate from camera permission. Check Enable face & body observations to load the local face model. Select Start 30-second face check. Move closer so your face is well lit and fills enough of the preview. Relax and look toward the camera; there is no need to perform facial expressions. An open-eye calibration period comes first. Early checks are labeled with their actual duration for comparison.

After the check, move back until the body is visible and select Recalibrate. Then launch the flight. The close-up face measurements are kept separate from intentional flight movements. Faces that are too small, dark, poorly oriented or poorly sampled produce unavailable measurements. Withdrawing consent ends an active check immediately and cancels pending observation loading.

## Combat and mind checks

The single two-minute flight has actual enemy drones, laser fire, drone attacks, asteroid impacts, shields, boosts and ducking. Protect the hull and fire along the flight path. After the flight ends, the mind check opens automatically.

Memory uses three patterns of 3, 4 and 5 directions. Watch the illuminated tiles, then repeat the pattern using arrows or taps. Body control can aim toward a direction and extend the arm to confirm. Incorrect input records an error and replays the current pattern.

The focus task has eight cues. Respond to cyan GO with Space, the Respond button or arm extension; do not respond to orange WAIT. P pauses/resumes. Hidden tabs and tracking loss pause tasks. Skip to report is available; partial task results remain visible but are not compared with completed tasks. Keyboard or tap use during a motion session marks mixed input and disables longitudinal comparison for that record.

## Journal and comparison

Enable Save reports on this device to keep up to 30 derived reports across visits. Current unsaved reports remain in memory only. The Health journal selects a current session and an earlier comparator. It prefers the newest usable comparable record and shows unavailable deltas with reasons. Quality gates, task protocol, duration and input mode prevent comparisons between different conditions. Labels use Asia/Baghdad calendar dates.

Demo preview always carries a FICTIONAL RECORDS banner and contains two synthetic sessions for yesterday/today. These records are never mixed with measured reports or silently stored. Demo exports are also labeled fictional. Export report saves derived JSON; Delete saved reports removes measured browser and in-memory records, not separately exported files.

## Meaning and limits

The detailed report describes visible events and task performance. It is not a medical diagnosis, clinical cognitive test, overall health score or evidence of fatigue, neurological disease, emotion, bone loss or muscle weakness. Camera motion does not supply astronaut resistance training. Suggested next steps concern camera conditions, repeated comparable sessions, comfortable breaks and qualified clinical review of persistent concerns.

Real-person camera accuracy and performance on your particular hardware still need a playtest. Automated synthetic landmarks and a synthetic camera verify implementation behavior, not clinical validity or human accuracy.
