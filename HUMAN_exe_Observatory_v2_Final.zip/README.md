# HUMAN.exe Human Observatory 2.0

A polished local browser demo with one 3D space-combat mission, hand and leg controls, post-flight memory and attention tasks, and detailed camera-observation reports with day-to-day comparison.

## Play

Double-click **START_HUMAN_EXE.cmd**. Node.js 22 or newer is required. The included production build runs locally without internet; keep the launcher window open. The game is served at localhost, usually port 4173.

## One continuous journey

1. Optionally enable face and body observations separately from camera controls.
2. Complete a relaxed 30-second close-up face check. Step back and recalibrate the full body.
3. Fly a two-minute orbital defense mission against enemy drones and asteroids.
4. Repeat three increasing memory patterns, then complete eight go/no-go attention trials.
5. Review the report and compare with earlier sessions. Enable local report saving to retain future reports across days.

## Controls

- Move the left hand to steer/aim; extend the right arm at shoulder height to fire. Both arms overhead activate the shield and take priority over firing.
- Complete a knee lift-and-lower cycle to boost; squat and stand to trigger evasive duck. Legs require hips, knees and ankles in view.
- Keyboard: WASD/arrows aim, J fires, Space shields, Shift boosts, C ducks, P pauses.
- Memory: arrows or tiles; with body control, aim toward a direction and extend the arm to confirm. Attention: Space, Respond button, or arm extension for cyan GO; withhold on orange WAIT.

## Reports

Face observations include approximate blink activity, eye-closure geometry, long closures, mouth openings and head roll. Body observations include shoulder-normalized wrist travel, completed leg actions, shield events, torso displacement and coverage. Task results describe pattern recall and attention responses.

Measurements are withheld when calibration, frame rate or coverage is inadequate. A close-up face check is important because full-body camera framing may make the face too small. Comparable reports need matching task protocols, input mode, session duration and usable camera evidence. Partial tasks and mixed input cannot create misleading deltas. Baghdad calendar dates label same-day and previous-day comparisons.

The **Demo preview** contains two clearly marked fictional records. It never enters measured history. This is a camera-observation demo, not a medical diagnostic tool; it does not infer disease, emotion, identity, vital signs, muscle health or bone density from appearance. A clinician needs appropriate clinical evidence to diagnose a condition.

## Privacy

No video, images or raw body/face landmarks are saved or uploaded. Optional local storage keeps at most 30 sanitized derived reports. Export and deletion are available in the Health journal. Camera controls, observation consent and local report saving are independent choices. Withdrawing observation consent cancels pending model loading and stops further observation.

## Development

Run npm install, npm run assets, and npm run dev. npm test runs the meaningful unit suite; npm run build creates dist. The current entry point is src/app-v2.js. Runtime libraries, OpenCV, pose/face models, WASM, React Bits and the custom mission artwork are bundled locally. Third-party notices and artwork prompts are included.

See PLAY_GUIDE.md and VERIFICATION.md for operation and testing limits. The earlier v1 ZIP is retained separately; HUMAN_exe_Observatory_v2_Final.zip is the updated release.
