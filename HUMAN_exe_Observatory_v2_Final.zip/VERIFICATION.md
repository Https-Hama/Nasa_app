# HUMAN.exe Human Observatory v2 verification

Verified on 14 November 2026 in this Windows workspace.

## Meaningful automated checks

The current Node suite has 79 passing tests covering pose confidence/calibration and body controls, hand aiming/fire/shield priority, complete knee/squat cycles, real combat projectile damage, enemy kills, shield blocks, boost/duck physics, bounded waves and resource disposal. Observation tests cover aspect-correct facial geometry, an open-eye baseline, approximate completed blink/closure/mouth events, missing or distant faces, poor lighting, inadequate frame rates, actual coverage denominators, paused/gapped evidence, body motion normalization and consent cancellation. Report tests cover strict derived-data whitelisting, same-day and previous-day Baghdad labels, quality gates, actual face-check duration, complete versus skipped task comparisons, mixed input, null evidence, and separation of demo records from measured history. Mental-task tests include playback input rejection, increasing memory rounds, false alarms/misses, stimulus deadlines and pause timing.

The production browser journey on localhost4173 verifies one core game, actual React Bits elements, explicit observation opt-in, a visibly fictional yesterday/today demo, report export without saving demo data, keyboard weapon fire, pause, all three memory rounds, all eight attention trials, a saved measured report with unavailable camera data instead of fabricated values, measured export/deletion, guide navigation, tablet/phone layout and mobile report layout without horizontal overflow. It completed with zero page/console errors. The combat renderer smoke separately recorded a real simulated drone kill and verified duck hitbox/render alignment.

## Camera runtime

OpenCV, MediaPipe WASM and both local landmark models are bundled in the production build. Frames pass through actual OpenCV preprocessing before inference. A real CPU face-model initialization test on a blank local-origin page loaded in approximately1.53seconds, inferred a no-person frame as zero faces and closed the model. The initial combined runtime stalled because the legacy OpenCV build left its self-returning runtime in the global Module variable, which MediaPipe treats as new-runtime configuration. The implementation now clears only that foreign configuration, serializes initialization, defaults face inference to CPU with fallback, and suspends background 3D while loading/checking. Real isolated OpenCV→face initialization then passed in approximately0.79seconds; OpenCV matrix and frame processing still worked after face teardown.

The completed production camera workflow report is retained under verification/v2-camera-check.json. It passed with the face model initializing in6.9seconds and397actual OpenCV-processed face detections during a full30-second check. The synthetic camera contained no person, so face metrics correctly remained null with zero valid seconds. Consent withdrawal closed the model, stopped inference/callbacks, ended the check and restored Launch while leaving the camera controls available. Disconnect ended the camera track. There were zero page/console errors, external requests or uploads. This verifies implementation behavior, not accuracy for a person.

## Limits and interpretation

No real person has performed the updated camera sequence on the intended webcam. Person-specific recognition, comfortable ranges, lighting robustness, body diversity and real hardware frame rates still require a hardware playtest. Camera blink counts and movement metrics are approximate geometry. Quality thresholds are engineering sampling checks, not clinical cutoffs.

The interface reports observations and task results, never diagnoses, emotion, identity, vital signs or a clinical health score. The optional demo is clearly fictional throughout the view and export and never mixes with measured records. Reports assume the same person uses the selected local journal; no identity recognition is performed.

The Vite production build succeeds with the existing advisory for the approximately525kB uncompressed Three.js vendor chunk (approximately136kB compressed). The earlier v1 release and verification evidence are retained separately.
