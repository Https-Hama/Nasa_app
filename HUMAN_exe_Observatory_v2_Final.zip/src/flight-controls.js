// Game-control thresholds only. Landmarks remain in memory and are never stored.
const clamp = (n, low, high) => Math.max(low, Math.min(high, n));
const ARMS = [11, 12, 13, 14, 15, 16, 23, 24];
const LEGS = [23, 24, 25, 26, 27, 28];
const valid = p => p && Number.isFinite(p.x) && Number.isFinite(p.y)
  && Math.min(p.visibility ?? 0, p.presence ?? p.visibility ?? 0) >= .55
  && p.x >= .015 && p.x <= .985 && p.y >= .015 && p.y <= .985;
function angle(a, b, c) {
  const ux = a.x - b.x, uy = a.y - b.y, vx = c.x - b.x, vy = c.y - b.y;
  const length = Math.hypot(ux, uy) * Math.hypot(vx, vy);
  return length > .00001 ? Math.acos(clamp((ux * vx + uy * vy) / length, -1, 1)) * 180 / Math.PI : 0;
}
const axis = n => Math.abs(n) < .1 ? 0 : Math.sign(n) * clamp((Math.abs(n) - .1) / .9, 0, 1);

export class FlightGestureRecognizer {
  constructor() { this.reset(); }

  reset() {
    this.neutral = null;
    this.pending = null;
    this.neutralSeen = false;
    this.lastNow = null;
    this.lastBoost = -Infinity;
    this.lastDuck = -Infinity;
  }

  update(landmarks, now, poseInput = {}) {
    const output = { x: 0, y: 0, shield: false, fire: false, boost: false, duck: false, controlsReady:false, gesture: 'Stand in view' };
    const usable = poseInput.calibrated && poseInput.tracked && Number.isFinite(now)
      && Array.isArray(landmarks) && ARMS.every(i => valid(landmarks[i]));
    if (!usable) {
      this.pending = null;
      this.neutralSeen = false;
      this.lastNow = null;
      if (!poseInput.calibrated) this.neutral = null;
      output.gesture = poseInput.calibrated ? 'Keep shoulders and hands in view' : 'Calibrate a neutral pose';
      return output;
    }
    if (this.lastNow !== null && (now <= this.lastNow || now - this.lastNow > 700)) {
      this.pending = null;
      this.neutralSeen = false;
    }
    this.lastNow = now;
    output.controlsReady=true;
    const p = landmarks;
    const shoulderX = (p[11].x + p[12].x) / 2;
    const shoulderY = (p[11].y + p[12].y) / 2;
    const hipY = (p[23].y + p[24].y) / 2;
    const torso = Math.max(.08, hipY - shoulderY);
    const width = Math.max(.1, Math.hypot(p[11].x - p[12].x, p[11].y - p[12].y));
    // Left hand aims independently so extending the right arm cannot push the
    // aiming position away from the target while it fires.
    const handX = (p[15].x - shoulderX) / width;
    const handY = (p[15].y - shoulderY) / torso;
    if (!this.neutral) this.neutral = { handX, handY, hipY, torso };
    output.x = axis(-(handX - this.neutral.handX) / .7);
    output.y = axis(-(handY - this.neutral.handY) / .8);
    output.shield = p[15].y < shoulderY - torso * .45 && p[16].y < shoulderY - torso * .45
      && p[13].y < shoulderY && p[14].y < shoulderY;
    output.fire = !output.shield && p[16].y < shoulderY + torso * .4 && angle(p[12], p[14], p[16]) > 150
      && Math.hypot(p[16].x - p[12].x, p[16].y - p[12].y) > width * 1.15;
    output.gesture = output.shield ? 'Shield active' : output.fire ? 'Firing' : 'Hands steer · extend right arm to fire';

    if (!poseInput.fullBody || !LEGS.every(i => valid(p[i]))) {
      this.pending = null;
      this.neutralSeen = false;
      return output;
    }
    const hipDrop = (hipY - this.neutral.hipY) / this.neutral.torso;
    const bent = angle(p[23], p[25], p[27]) < 160 && angle(p[24], p[26], p[28]) < 160;
    const squatting = hipDrop > .25 && bent;
    const lifted = !squatting && Math.min(p[25].y, p[26].y) < hipY + torso * .22;
    const neutral = hipDrop < .17 && p[25].y > hipY + torso * .55 && p[26].y > hipY + torso * .55;
    if (neutral) {
      const pending = this.pending;
      if (pending?.ready && now - pending.at <= 3500) {
        if (pending.type === 'knee' && now - this.lastBoost >= 4000) {
          output.boost = true;
          output.kneeLift = true;
          output.gesture = 'Knee cycle complete · boost';
          this.lastBoost = now;
        }
        if (pending.type === 'squat' && now - this.lastDuck >= 2200) {
          output.duck = true;
          output.squat = true;
          output.gesture = 'Squat cycle complete · duck';
          this.lastDuck = now;
        }
      }
      this.pending = null;
      this.neutralSeen = true;
    } else {
      const type = squatting ? 'squat' : lifted ? 'knee' : null;
      if (type && this.neutralSeen) {
        if (!this.pending) this.pending = { type, at: now, ready: false };
        else if (this.pending.type !== type) {
          this.pending = null;
          this.neutralSeen = false;
        } else if (now - this.pending.at >= 250) this.pending.ready = true;
      } else if (!type) {
        this.pending = null;
      }
    }
    return output;
  }
}
