import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {mkdir,writeFile,readFile} from 'node:fs/promises';
await mkdir('artifacts',{recursive:true});
const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',args:['--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const context=await browser.newContext({viewport:{width:1600,height:1050},acceptDownloads:true});
const page=await context.newPage();const errors=[];const checks=[];
page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
const pass=text=>{checks.push(text);console.log('PASS:',text);};
try{
 await page.goto('http://127.0.0.1:4173',{waitUntil:'networkidle'});await page.locator('#launch').waitFor();
 assert.equal(await page.locator('[data-mission]').count(),0);assert.equal(await page.locator('#launch-react canvas').count(),1);
 assert.equal(await page.locator('#face-check').isDisabled(),true);assert.equal(await page.locator('#observation-consent').isChecked(),false);
 await page.screenshot({path:'artifacts/HUMAN-v2-flight.png',fullPage:true});pass('One game, React Bits and separate observation consent render.');
 await page.locator('#demo-preview').click();assert.equal(await page.locator('.demo-banner').isVisible(),true);assert.equal(await page.locator('.trend-svg').count(),2);
 assert.match(await page.locator('.comparison-status').textContent(),/Yesterday/);
 assert.equal(await page.evaluate(()=>localStorage.getItem('human-exe-observations-v2')),null);
 await page.screenshot({path:'artifacts/HUMAN-v2-report.png',fullPage:true});
 const demoDownload=page.waitForEvent('download');await page.locator('#export-report').click();const demo=await demoDownload;await demo.saveAs('artifacts/demo-report-v2.json');
 const demoJSON=JSON.parse(await readFile('artifacts/demo-report-v2.json','utf8'));assert.equal(demoJSON.record.source,'demo');assert.match(demoJSON.kind,/FICTIONAL/);pass('Detailed demo compares yesterday/today, labels synthetic values and does not save them.');
 await page.locator('[data-view="flight"]').click();await page.locator('#save-reports').check();await page.locator('#launch').click();await page.keyboard.down('j');await page.waitForTimeout(2500);await page.keyboard.up('j');await page.keyboard.press('Shift');await page.keyboard.press('c');
 await page.screenshot({path:'artifacts/HUMAN-v2-combat.png',fullPage:true});await page.keyboard.press('p');const frozen=await page.locator('#hud-time').textContent();await page.waitForTimeout(900);assert.equal(await page.locator('#hud-time').textContent(),frozen);await page.locator('#resume').click();await page.keyboard.press('p');await page.locator('#end-flight').click();
 await page.locator('#mind-dialog[open]').waitFor();
 await page.evaluate(()=>{window.__patternEvents=[];window.__lastLit='';window.__capture=setInterval(()=>{const d=document.querySelector('[data-mind-direction].lit')?.dataset.mindDirection||'';if(d&&d!==window.__lastLit)window.__patternEvents.push(d);window.__lastLit=d;},25);});
 for(let round=0;round<3;round++){
  await page.waitForFunction(()=>document.querySelector('#mind-status').textContent.startsWith('YOUR TURN'),{},{timeout:15000});
  const events=await page.evaluate(()=>window.__patternEvents.splice(0));
  assert.equal(events.length,round+3,`Observed full visible pattern round${round+1}`);
  if(round===0)await page.screenshot({path:'artifacts/HUMAN-v2-mind.png'});
  for(const direction of events){await page.keyboard.press({left:'ArrowLeft',up:'ArrowUp',right:'ArrowRight',down:'ArrowDown'}[direction]);await page.waitForTimeout(90);}
 }
 await page.evaluate(()=>clearInterval(window.__capture));
 await page.waitForFunction(()=>document.querySelector('#mind-task-label').textContent.includes('FOCUS'));
 for(let trial=0;trial<8;trial++){
  await page.waitForFunction(()=>['GO','WAIT'].includes(document.querySelector('#cue-word').textContent),{},{timeout:8000});
  const cue=await page.locator('#cue-word').textContent();if(cue==='GO'){await page.waitForTimeout(180);await page.keyboard.press('Space');}
  await page.waitForFunction(()=>!['GO','WAIT'].includes(document.querySelector('#cue-word')?.textContent||''),{},{timeout:4000});
 }
 await page.waitForSelector('#journal-view:not([hidden])',{timeout:7000});assert.equal(await page.locator('.demo-banner').count(),0);assert.match(await page.locator('.report-summary').textContent(),/Face check unavailable/);
 const real=await page.evaluate(()=>JSON.parse(localStorage.getItem('human-exe-observations-v2')));assert.equal(real.length,1);assert.equal(real[0].source,'measured');assert.equal(real[0].cognitive.memory.rounds,3);assert.equal(real[0].cognitive.attention.attempts,8);assert.ok(real[0].game.shots>0);assert.equal(real[0].observations.face.blinkRate,null);
 pass('Combat fires real shots; pause works; 3 memory rounds and 8 attention trials produce a saved measured report.');
 const realDownload=page.waitForEvent('download');await page.locator('#export-report').click();const realFile=await realDownload;await realFile.saveAs('artifacts/measured-report-v2.json');
 const json=JSON.parse(await readFile('artifacts/measured-report-v2.json','utf8'));assert.equal('landmarks' in json.record,false);assert.equal('video' in json.record,false);
 await page.locator('#delete-reports').click();assert.equal(await page.evaluate(()=>localStorage.getItem('human-exe-observations-v2')),null);pass('Measured export contains derived values; deletion removes measured reports.');
 await page.locator('[data-view="guide"]').click();assert.equal(await page.locator('.guide-card').count(),4);await page.locator('[data-view="flight"]').click();
 for(const viewport of [{width:768,height:1024},{width:390,height:844}]){await page.setViewportSize(viewport);await page.waitForTimeout(350);assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true,`No overflow at${viewport.width}`);await page.screenshot({path:`artifacts/HUMAN-v2-${viewport.width}.png`,fullPage:true});}
 await page.locator('#demo-preview').click();assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true,'Phone report has no overflow');await page.screenshot({path:'artifacts/HUMAN-v2-report-mobile.png',fullPage:true});
 pass('Guide, tablet, phone and detailed mobile report layouts work without horizontal overflow.');
 assert.deepEqual(errors,[]);await writeFile('artifacts/browser-verification-v2.json',JSON.stringify({checkedAt:new Date().toISOString(),production:'http://127.0.0.1:4173',checks,errors,passed:true},null,2));console.log(JSON.stringify({checks:checks.length,errors},null,2));
}catch(e){await page.screenshot({path:'artifacts/v2-browser-failure.png',fullPage:true}).catch(()=>{});console.error(await page.locator('body').innerText().catch(()=>''));throw e;}finally{await browser.close();}
